ThoughtSpot to Power BI Large Test Package

This is synthetic demo data for testing and presentation.
It includes:
- Large CSV source table with 65,000 rows
- 10 ThoughtSpot-style .tml workbook files
- 25 JSON metadata objects
- Many worksheets, calculated fields, filters, joins, formulas, and DAX conversion cases
- Large glossary/test notes file to make the package above 5 MB

Use it for:
- Upload testing
- Dashboard/worksheet count testing
- Calculated field mapping
- DAX conversion page
- Download package testing
- Presentation demo

Note: This is synthetic demo data, not real customer/company data.
